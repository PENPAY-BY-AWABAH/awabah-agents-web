/* eslint-disable @typescript-eslint/no-unused-vars */
import { UserCheckIcon } from "@/app/assets/user-check-icon"
import { UserPendingIcon } from "@/app/assets/user-pending-icon"
import { UserRejectIcon } from "@/app/assets/user-reject-icon"
import { UsersIcon } from "@/app/assets/users-icon"
import useHttpHook from "@/app/includes/useHttpHook"
import { ReactElement, useEffect, useState } from "react"
export interface TabSectionProp {
    title:string;
    icon?:string | ReactElement;
    description?:string;
    bgColour?:string;
    borderColour?:string;
    route?:string;
    value?:UsersStatsType;
    selected?:boolean;
}
type UsersStatsType = "usersOnboarded" | "userRemit" | "withdrawal" | "rejected";
export interface UsersStatsProps {
  usersOnboarded: number;
  userRemit: number;
  withdrawal: number;
  rejected: number;
}

export const TabSection = ()=>{
    const {getAllUserStats} = useHttpHook()
    const [stats,setStats] = useState<UsersStatsProps>({
        rejected:0,
        userRemit:0,
        usersOnboarded:0,
        withdrawal:0
    });
      const [btns,setBtns] = useState<TabSectionProp[]>([
            {
            title:"Users Onboarded",
            icon:<UsersIcon size={40} />,
            route:"text-[#1879F8]",
            selected:true,
            bgColour:"bg-[#1879F826]",
            borderColour:"border-[#1879F8]",
            value:"usersOnboarded"
            },
            {
            title:"Remit",
            icon:<UserCheckIcon />,
            route:"text-[#009668]",
            selected:false,
            bgColour:"bg-[#00966826]",
            borderColour:"border-[#009668]",
            description:"3893",
            value:"userRemit"
            },
            {
            title:"Withdrawal History",
            icon:<UserPendingIcon />,
            route:"text-[#F4900C]",
            selected:false,
            bgColour:"bg-[#F4900C26]",
            borderColour:"border-[#F4900C]",
            description:"390",
            value:"withdrawal"
            },
            {
            title:"Pending Onboarding",
            icon:<UserRejectIcon />,
            route:"text-[#EE1A1A]",
            selected:false,
            bgColour:"bg-[#EE1A1A26]",
            borderColour:"border-[#EE1A1A]",
            description:"0",
            value:"rejected"
            }
        ])
    useEffect(()=>{
        getAllUserStats().then((res)=>{
            if(res.status)
            {
                setStats(res.data)
            }
        })
    },[])
    return <div>
        <div className="lg:flex grid grid-cols-2 items-center gap-[16px] lg:gap-9 my-8 mt-3">
            {btns.map((a,i)=><div key={i} className={`${a.bgColour} ${a.borderColour} border-[1px] h-[180px] grid grid-cols-1 text-center items-center flex-1 rounded-[20px] lg:rounded-[40px] p-8 min-h-[163px]`} >
            <div className={`text-center m-auto ${a.route} ${String(a.borderColour).replace("border","text")} `}>{a.icon}</div>
            <div className="text-center text-black font-medium text-[20px] lg:text-[28.3px] lg:mt-3">{(stats[a.value!] || 0)}</div>
            <div className="text-center text-black text-[12px] lg:text-[18.8px] lg:mt-3">{a.title}</div>
            </div>)}
        </div>
    </div>
}