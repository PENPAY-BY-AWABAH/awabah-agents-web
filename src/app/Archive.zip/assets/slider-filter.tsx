export const SliderIcon = ()=>{
    return <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M3.75 9V3M14.25 15V12.75M3.75 15V12M14.25 9.75V3M9 5.25V3M9 15V8.25" stroke="black" strokeLinecap="round"/>
<path d="M3.75 12C4.57843 12 5.25 11.3284 5.25 10.5C5.25 9.67157 4.57843 9 3.75 9C2.92157 9 2.25 9.67157 2.25 10.5C2.25 11.3284 2.92157 12 3.75 12Z" stroke="black" strokeLinecap="round"/>
<path d="M9 8.25C9.82843 8.25 10.5 7.57843 10.5 6.75C10.5 5.92157 9.82843 5.25 9 5.25C8.17157 5.25 7.5 5.92157 7.5 6.75C7.5 7.57843 8.17157 8.25 9 8.25Z" stroke="black" strokeLinecap="round"/>
<path d="M14.25 12.75C15.0784 12.75 15.75 12.0784 15.75 11.25C15.75 10.4216 15.0784 9.75 14.25 9.75C13.4216 9.75 12.75 10.4216 12.75 11.25C12.75 12.0784 13.4216 12.75 14.25 12.75Z" stroke="black" strokeLinecap="round"/>
</svg>

}