
export default function Page() {
  return (
    <div className="flex h-screen items-center justify-center bg-white font-sans text-black">
      Not Found
    </div>
  );
}
