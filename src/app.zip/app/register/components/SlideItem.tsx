import { SlideItemProp } from "@/app/includes/types"

export const SlideItem = ({
    id,
    description,
    graphics,
    title
}:SlideItemProp)=>{
    return <div >

    </div>
}