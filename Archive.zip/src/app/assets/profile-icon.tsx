export const ProfileIcon = ()=>{
    return <svg 
 width="17" height="21" viewBox="0 0 17 21" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M8.5 8.5C10.7091 8.5 12.5 6.70914 12.5 4.5C12.5 2.29086 10.7091 0.5 8.5 0.5C6.29086 0.5 4.5 2.29086 4.5 4.5C4.5 6.70914 6.29086 8.5 8.5 8.5Z" stroke="currentColor"/>
<path d="M16.5 16C16.5 18.485 16.5 20.5 8.5 20.5C0.5 20.5 0.5 18.485 0.5 16C0.5 13.515 4.082 11.5 8.5 11.5C12.918 11.5 16.5 13.515 16.5 16Z" stroke="currentColor"/>
</svg>


}