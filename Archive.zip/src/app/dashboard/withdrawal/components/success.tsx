export const WithdrawalSuccessScreen = ({onClose}:{onClose:()=>void})=>{
return <div ></div>
}